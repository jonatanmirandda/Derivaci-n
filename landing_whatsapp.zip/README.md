# Landing WhatsApp Rotador

Este proyecto es una landing simple que rota varios números de WhatsApp a través de una hoja de cálculo de Google Sheets.

## Instrucciones

1. Crea una Google Sheet con dos columnas: `numero` y `habilitado`.
2. Usa Google Apps Script para publicar la hoja como API JSON (con `doGet`).
3. Reemplaza la línea `const sheetAPI = 'TU_URL_PUBLICA_DEL_DEPLOY';` en el `index.html`.
4. Subí este proyecto a GitHub y activá GitHub Pages para que quede online.

